package com.alipay.easysdk.kms.aliyun.credentials.utils;

public class StringUtils {
    public static boolean isEmpty(final CharSequence cs) {
        return cs == null || cs.length() == 0;
    }
}
