package com.alipay.easysdk.kms.aliyun.credentials.utils;

public class CredentialType {
    public static final String ACCESS_KEY = "access_key";
    public static final String STS = "sts";
    public static final String ECS_RAM_ROLE = "ecs_ram_role";
    public static final String RAM_ROLE_ARN = "ram_role_arn";
}
