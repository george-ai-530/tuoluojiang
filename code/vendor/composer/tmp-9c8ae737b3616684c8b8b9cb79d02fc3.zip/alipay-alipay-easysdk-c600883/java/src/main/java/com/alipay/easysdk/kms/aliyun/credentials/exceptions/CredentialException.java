package com.alipay.easysdk.kms.aliyun.credentials.exceptions;

public class CredentialException extends Exception {
    public CredentialException(String message) {
        super(message);
    }
    @Override
    public String getMessage() {
        return super.getMessage();
    }
}
