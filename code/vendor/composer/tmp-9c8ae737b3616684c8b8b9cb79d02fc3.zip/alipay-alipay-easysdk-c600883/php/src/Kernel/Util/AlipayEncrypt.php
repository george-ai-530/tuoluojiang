<?php


namespace Alipay\EasySDK\Kernel\Util;


class AlipayEncrypt
{
    const AES_ALG = "AES";
    const AES_CBC_PCK_ALG = "AES/CBC/PKCS5Padding";

}