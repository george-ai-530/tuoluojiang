<?php

namespace Alipay\EasySDK\Kernel\Exceptions;

use Exception;

class RuntimeException extends Exception
{

}