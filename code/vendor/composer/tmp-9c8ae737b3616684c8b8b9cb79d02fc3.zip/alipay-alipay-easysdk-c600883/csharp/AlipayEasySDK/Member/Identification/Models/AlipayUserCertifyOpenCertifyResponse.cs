// This file is auto-generated, don't edit it. Thanks.

using System;
using System.Collections.Generic;
using System.IO;

using Tea;

namespace Alipay.EasySDK.Member.Identification.Models
{
    public class AlipayUserCertifyOpenCertifyResponse : TeaModel {
        /// <summary>
        /// 认证服务请求地址
        /// </summary>
        [NameInMap("body")]
        [Validation(Required=true)]
        public string Body { get; set; }

    }

}
