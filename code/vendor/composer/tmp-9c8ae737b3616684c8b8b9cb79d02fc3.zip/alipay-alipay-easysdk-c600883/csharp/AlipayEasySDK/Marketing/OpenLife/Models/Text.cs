// This file is auto-generated, don't edit it. Thanks.

using System;
using System.Collections.Generic;
using System.IO;

using Tea;

namespace Alipay.EasySDK.Marketing.OpenLife.Models
{
    public class Text : TeaModel {
        [NameInMap("title")]
        [Validation(Required=true)]
        public string Title { get; set; }

        [NameInMap("content")]
        [Validation(Required=true)]
        public string Content { get; set; }

    }

}
