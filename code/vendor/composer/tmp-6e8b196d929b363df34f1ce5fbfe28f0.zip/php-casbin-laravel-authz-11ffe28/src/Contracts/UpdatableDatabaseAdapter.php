<?php

namespace Lauthz\Contracts;

use Casbin\Persist\UpdatableAdapter;

interface UpdatableDatabaseAdapter extends UpdatableAdapter
{
}
