<?php

namespace Lauthz\Contracts;

use Casbin\Persist\FilteredAdapter;

interface FilteredDatabaseAdapter extends FilteredAdapter
{
}
