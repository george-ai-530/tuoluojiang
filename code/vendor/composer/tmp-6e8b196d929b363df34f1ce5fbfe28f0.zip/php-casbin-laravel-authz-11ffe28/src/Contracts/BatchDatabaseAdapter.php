<?php

namespace Lauthz\Contracts;

use Casbin\Persist\BatchAdapter;

interface BatchDatabaseAdapter extends BatchAdapter
{
}
