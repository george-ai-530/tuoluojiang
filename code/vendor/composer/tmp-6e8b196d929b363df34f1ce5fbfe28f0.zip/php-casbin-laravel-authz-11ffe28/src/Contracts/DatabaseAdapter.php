<?php

namespace Lauthz\Contracts;

use Casbin\Persist\Adapter;

interface DatabaseAdapter extends Adapter
{
}
