<?php

namespace Lauthz\Contracts;

interface Factory
{
}
